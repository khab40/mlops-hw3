"""LangGraph agent: text-to-SQL with verify+revise loop.

Graph shape:

    START -> attach_schema -> generate_sql -> execute -> verify
                                                          |
                                              ok=true ----+----> END
                                                          |
                                              ok=false ---+----> revise -> execute -> verify (loop)

Loop is capped at MAX_ITERATIONS total generate/revise calls.

The execute node and the graph wiring are provided. `generate_sql_node` is
filled in as a worked example; you implement `verify`, `revise`, and the
conditional router following the same shape.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Any

from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnableConfig
from langgraph.graph import END, START, StateGraph

from agent import prompts
from agent.execution import ExecutionResult, execute_sql
from agent.metrics import timed_node
from agent.schema import render_schema, trim_schema_for_question

# Total generate + revise calls before the loop is forced to stop.
# 3-5 is a reasonable range; tune it as part of Phase 3.
MAX_ITERATIONS = 3

VLLM_BASE_URL = os.environ.get("VLLM_BASE_URL", "http://localhost:8000/v1")
VLLM_MODEL = os.environ.get("VLLM_MODEL", "Qwen/Qwen3-30B-A3B-Instruct-2507")
# vLLM ignores the key, but a hosted OpenAI-compatible provider needs a real one.
# Lets you point the agent at e.g. OpenAI while iterating without a running vLLM.
LLM_API_KEY = os.environ.get("OPENAI_API_KEY", "not-needed")
LLM_MAX_TOKENS = int(os.environ.get("AGENT_MAX_TOKENS", "256"))


@dataclass
class AgentState:
    """State threaded through the graph. Extend with fields you need."""

    question: str
    db_id: str
    schema: str = ""
    sql: str = ""
    execution: ExecutionResult | None = None
    verify_ok: bool = False
    verify_issue: str = ""
    iteration: int = 0
    history: list[dict[str, Any]] = field(default_factory=list)


def llm() -> ChatOpenAI:
    """Chat client pointed at VLLM_BASE_URL (your local vLLM by default)."""
    return ChatOpenAI(
        model=VLLM_MODEL,
        base_url=VLLM_BASE_URL,
        api_key=LLM_API_KEY,
        temperature=0.0,
        max_tokens=LLM_MAX_TOKENS,
    )


# ---- Nodes ------------------------------------------------------------

def _attach_schema(state: AgentState) -> dict:
    """Provided. Render the DB schema once at the start of the run."""
    with timed_node("attach_schema"):
        schema = render_schema(state.db_id)
        return {"schema": trim_schema_for_question(schema, state.question)}


def _extract_sql(text: str) -> str:
    """Pull a SQL statement out of an LLM reply, stripping markdown fences/prose.

    Intentionally simple: take the first ```sql ... ``` block if there is one,
    otherwise the whole reply. You may need to harden this for your prompts.
    """
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    fenced = re.search(r"```(?:sql)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
    sql = (fenced.group(1) if fenced else text).strip()
    start = re.search(r"\b(WITH|SELECT)\b", sql, re.IGNORECASE)
    if start:
        sql = sql[start.start():]
    sql = sql.strip().rstrip("`").strip()
    if ";" in sql:
        sql = sql[: sql.rfind(";") + 1]
    return sql


def _extract_json_object(text: str) -> dict[str, Any]:
    """Parse the first JSON object from an LLM reply."""
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
    candidate = (fenced.group(1) if fenced else text).strip()
    try:
        parsed = json.loads(candidate)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError:
        pass

    start = candidate.find("{")
    end = candidate.rfind("}")
    if start != -1 and end > start:
        try:
            parsed = json.loads(candidate[start : end + 1])
            return parsed if isinstance(parsed, dict) else {}
        except json.JSONDecodeError:
            return {}
    return {}


def generate_sql_node(state: AgentState, config: RunnableConfig) -> dict:
    """Worked example - the other LLM nodes follow this same shape.

    Build messages from the prompts, call the shared llm(), extract the SQL,
    and return only the state fields you changed. `iteration` is bumped here
    (and in revise) so route_after_verify can enforce MAX_ITERATIONS.

    This node is wired and ready; fill in GENERATE_SQL_SYSTEM / GENERATE_SQL_USER
    in prompts.py to make it produce real queries.
    """
    with timed_node("generate_sql"):
        response = llm().invoke(
            [
                ("system", prompts.GENERATE_SQL_SYSTEM),
                ("user", prompts.GENERATE_SQL_USER.format(
                    schema=state.schema,
                    question=state.question,
                )),
            ],
            config=config,
        )
        sql = _extract_sql(response.content)
        return {
            "sql": sql,
            "iteration": state.iteration + 1,
            "history": state.history + [{"node": "generate_sql", "sql": sql}],
        }


def execute_node(state: AgentState) -> dict:
    """Provided. Runs the SQL and stores the result."""
    with timed_node("execute"):
        return {"execution": execute_sql(state.db_id, state.sql)}


def verify_node(state: AgentState, config: RunnableConfig) -> dict:
    """Decide whether state.execution plausibly answers state.question.

    Follow the generate_sql_node pattern: build messages from the VERIFY_*
    prompts, call llm(), parse the reply. Ask the model for a small JSON object
    like {"ok": bool, "issue": str} and parse it defensively - the model may
    wrap it in prose or fences. state.execution.render() gives you a compact
    view of the rows or error to feed into the prompt.

    Return: {"verify_ok": <bool>, "verify_issue": <str>}.
    What counts as "not plausible" is yours to define - see the Phase 3 targets
    in the README.
    """
    with timed_node("verify"):
        execution = state.execution.render() if state.execution else "ERROR: SQL was not executed."
        response = llm().invoke(
            [
                ("system", prompts.VERIFY_SYSTEM),
                ("user", prompts.VERIFY_USER.format(
                    question=state.question,
                    sql=state.sql,
                    execution=execution,
                )),
            ],
            config=config,
        )
        parsed = _extract_json_object(response.content)
        ok = bool(parsed.get("ok", False))
        issue = str(parsed.get("issue") or "").strip()
        if not issue:
            issue = "Verifier accepted the result." if ok else "Verifier rejected the result without a reason."
        return {
            "verify_ok": ok,
            "verify_issue": issue,
            "history": state.history + [{
                "node": "verify",
                "ok": ok,
                "issue": issue,
                "raw": response.content,
            }],
        }


def revise_node(state: AgentState, config: RunnableConfig) -> dict:
    """Produce a revised SQL query given state.verify_issue and the prior attempt.

    Same shape as generate_sql_node, but the prompt should include the failing
    SQL, its execution result, and the verifier's complaint so the model can fix
    it. Bump the iteration counter the same way generate_sql_node does so the
    loop terminates.

    Return: {"sql": <str>, "iteration": state.iteration + 1, ...}.
    """
    with timed_node("revise"):
        execution = state.execution.render() if state.execution else "ERROR: SQL was not executed."
        response = llm().invoke(
            [
                ("system", prompts.REVISE_SYSTEM),
                ("user", prompts.REVISE_USER.format(
                    schema=state.schema,
                    question=state.question,
                    sql=state.sql,
                    execution=execution,
                    issue=state.verify_issue,
                )),
            ],
            config=config,
        )
        sql = _extract_sql(response.content)
        return {
            "sql": sql,
            "iteration": state.iteration + 1,
            "history": state.history + [{
                "node": "revise",
                "issue": state.verify_issue,
                "sql": sql,
            }],
        }


def route_after_verify(state: AgentState) -> str:
    """Conditional router: return "revise" to loop, "end" to terminate.

    Two reasons to end: the verifier was happy (state.verify_ok), or you've hit
    the iteration cap (state.iteration >= MAX_ITERATIONS). Otherwise, revise.
    """
    if state.verify_ok or state.iteration >= MAX_ITERATIONS:
        return "end"
    return "revise"


# ---- Graph wiring -----------------------------------------------------

def build_graph():
    g = StateGraph(AgentState)
    g.add_node("attach_schema", _attach_schema)
    g.add_node("generate_sql", generate_sql_node)
    g.add_node("execute", execute_node)
    g.add_node("verify", verify_node)
    g.add_node("revise", revise_node)

    g.add_edge(START, "attach_schema")
    g.add_edge("attach_schema", "generate_sql")
    g.add_edge("generate_sql", "execute")
    g.add_edge("execute", "verify")
    g.add_conditional_edges(
        "verify",
        route_after_verify,
        {"revise": "revise", "end": END},
    )
    g.add_edge("revise", "execute")
    return g.compile()


graph = build_graph()


def run_fast_path(state: AgentState, config: RunnableConfig) -> dict[str, Any]:
    """Latency-optimized serving path: generate once, execute once, skip verify/revise."""
    state.schema = _attach_schema(state)["schema"]

    generated = generate_sql_node(state, config)
    state.sql = generated["sql"]
    state.iteration = generated["iteration"]
    state.history = generated["history"]

    executed = execute_node(state)
    state.execution = executed["execution"]
    return {
        "schema": state.schema,
        "sql": state.sql,
        "iteration": state.iteration,
        "history": state.history,
        "execution": state.execution,
        "verify_ok": True,
        "verify_issue": "fast path skipped verifier",
    }
